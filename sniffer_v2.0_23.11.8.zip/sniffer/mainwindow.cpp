#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTableWidgetItem>
#include <QDebug>
#include <QRegularExpression>
#include <QValidator>
#include <QMessageBox>
#include <pcap.h>
#include <QDateTime>
#include <QFile>
using namespace std;


void MainWindow::freedevs(pcap_if_t *devs){
    pcap_freealldevs(devs);
}

bool MainWindow::setNetdevs(){
    if(pcap_findalldevs(&devs,errbuf) == -1)
    {
        qDebug()<<errbuf;
        return 0;
    }
    for(devi = devs;devi;devi=devi->next)
    {
        if(devi)
        {
            ui->netbox->addItem(devi->description);
        }
    }
    return 1;
}

void MainWindow::setfilt()
{
    //设置过滤协议
    ui->protocolbox->addItem("all");
    ui->protocolbox->addItem("tcp");
    ui->protocolbox->addItem("udp");
    ui->protocolbox->addItem("ipv4");
    ui->protocolbox->addItem("icmp");
    ui->protocolbox->addItem("arp");
    ui->protocolbox->addItem("http");
    ui->protocolbox->addItem("https");
    ui->protocolbox->addItem("ftp");
    ui->protocolbox->addItem("smtp");
    ui->protocolbox->addItem("pop3");




    //设置包数量统计初始值
    ui->tcpline->setText("0");
    ui->udpline->setText("0");
    ui->ipv4line->setText("0");
    ui->arpline->setText("0");
    ui->icmpline->setText("0");
    ui->httpline->setText("0");
    ui->ftpline->setText("0");
    ui->smtpline->setText("0");
    ui->pop3line->setText("0");
    ui->otherline->setText("0");
    ui->toalline->setText("0");


}

void MainWindow::set_table_tree()
{
    //设置实时抓取表格
    ui->cap_table->verticalHeader()->setVisible(false);//隐藏第一列编号
    ui->cap_table->setEditTriggers(QAbstractItemView::NoEditTriggers);//设置表格不可修改
    ui->cap_table->setColumnCount(9);
    ui->cap_table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//设置列宽适应性，后期在做改动
    QStringList header;
    header<< tr("序号") << tr("时间")<< tr("源MAC地址")<< tr("源IP地址") << tr("目的MAC地址")<< tr("目的IP地址")<< tr("长度") << tr("协议类型")<<tr("包信息");
    ui->cap_table->setHorizontalHeaderLabels(header);
    //设置包细节内容查看表
    ui->detail_table->verticalHeader()->setVisible(false);
    ui->detail_table->setColumnCount(3);
    ui->detail_table->horizontalHeader()->setVisible(false);
    //设置包分析树
    ui->protocol_tree->setHeaderLabels(QStringList("数据包分析"));
}

int MainWindow::startcap()
{
    int net_index = 0;
    int netmask;
    struct bpf_program fil_sturct;

    //找到选中的网卡
    net_index = ui->netbox->currentIndex();
    qDebug()<<"net_index"<<net_index;
    nowdev = devs;
    for(int i=0;i<net_index;i++){
        nowdev = nowdev->next;
    }
    qDebug()<<"netinfo:"<<nowdev->description;

    //数据包捕获描述字
    pk_handle = pcap_open_live(nowdev->name,65536,1,1000,errbuf);
    if(pk_handle == NULL)
    {
        QMessageBox::warning(this, "open error","数据包捕获描述字获取失败", QMessageBox::Ok);
        freedevs(devs);
        devs=NULL;
        return -1;
    }

    //判断是否为以太网
    int isen = -1;
    if(pcap_datalink(pk_handle) == DLT_EN10MB){
        isen = 0;
    }
    else if(pcap_datalink(pk_handle) == DLT_IEEE802_11)
    {
        isen = 1;
    }

    if(isen != 0)
    {

        QMessageBox::warning(this, "net error","网络类型错误，仅支持以太网", QMessageBox::Ok);
        freedevs(devs);
        devs=NULL;
        return -1;
    }

    //获取过滤规则
    if(nowdev->addresses !=NULL)
    {
        netmask = ((struct sockaddr_in *)(nowdev->addresses->netmask))->sin_addr.S_un.S_addr;
    }
    else
    {
        netmask = 0xffffff;
    }

    QString nowpro = ui->protocolbox->currentText();
    qDebug()<<"start....nowpro:"<<nowpro;
    QString nowsrcip = ui->srcline->text();
    QString nowdesip = ui->desline->text();
    QString filterContent = getfilter(nowpro,nowsrcip,nowdesip);
    QByteArray bytea = filterContent.toLatin1();
    char *filter = NULL;
    filter = bytea.data();
    qDebug()<<"startcp....filter:"<<filter;
    if(filterContent == "error"){
        QMessageBox::warning(this, "filter error","无法编译包过滤器", QMessageBox::Ok);
        freedevs(devs);
        devs = NULL;
        return -1;
    }
    if(pcap_compile(pk_handle,&fil_sturct,filter,1,netmask)<0)
    {
        QMessageBox::warning(this, "filter error","无法编译包过滤器", QMessageBox::Ok);
        freedevs(devs);
        devs = NULL;
        return -1;
    }
    //设置过滤器
    if(pcap_setfilter(pk_handle,&fil_sturct)<0)
    {
        QMessageBox::warning(this, "filter error","无法编译包过滤器", QMessageBox::Ok);
        freedevs(devs);
        devs = NULL;
        return -1;
    }

    cap = new cap_poket(pk_handle,pk_cont,pk_vec,data_vec);
    connect(cap, SIGNAL(addOneCaptureLine(QString,QString,QString,QString,QString,QString,QString)), this, SLOT(updateTableWidget(QString,QString,QString,QString,QString,QString,QString)));
    connect(cap, SIGNAL(updatePktCont()), SLOT(updateCapCalculate()));
    cap->start();
    qDebug()<<"startcap end.....";
    return 1;
}

int MainWindow::initcap()
{
    devCount = 0;
    if(pcap_findalldevs(&devs, errbuf) == -1)
        return -1;
    for(devi = devs; devi; devi = devi->next)
        devCount++;
    return 0;
}

void MainWindow::pk_content16(u_char *print_data, int len)
{
    int de_ta_row = 0;//用于添加一行
    ui->detail_table->setRowCount(de_ta_row);
    ui->detail_table->horizontalHeader()->setVisible(false);
    QString line;
    QString line_data_16;
    QString line_data;
    for(int i=0 ; i<len ; i++)
    {
        if(i%16 == 0)
        {
            line +=QString("%1").arg(i,4,16,QLatin1Char('0'));

        }
        line_data_16 +=QString("%1 ").arg(print_data[i],2,16,QLatin1Char('0'));

        if(QChar(print_data[i]).isPrint())
        {
            line_data +=static_cast<QChar>(print_data[i]);
        }
        else
        {
            line_data += ".";
        }
        if((i+1)%16 == 0){
            de_ta_row = ui->detail_table->rowCount();
            ui->detail_table->insertRow(de_ta_row);
            ui->detail_table->setItem(de_ta_row, 0, new QTableWidgetItem(line));
            ui->detail_table->setItem(de_ta_row, 1, new QTableWidgetItem(line_data_16));
            ui->detail_table->setItem(de_ta_row, 2, new QTableWidgetItem(line_data));
            line.clear();
            line_data_16.clear();
            line_data.clear();
        }
    }
}

void MainWindow::pk_tree_anainfo(poketdata *onepk_data,int row)
{
    QString tree_str;
    tree_str = QString("第%1个数据包").arg(row);

    QTreeWidgetItem *root = new QTreeWidgetItem(ui->protocol_tree);
    root->setText(0, tree_str);

    //处理帧数据
    pk_tree_anainfo_mac(onepk_data,root);

    //处理ARP IP类型的数据包
    if(onepk_data->machead->type == 0x0806)      //ARP
    {
        pk_tree_anainfo_arp(onepk_data,root);
    }
    //处理ip包，包含udp tcp icmp
    else if(onepk_data->machead->type == 0x0800)
    {
        pk_tree_anainfo_ip(onepk_data,root);

        //处理传输层udp, icmp, tcp
        //ICMP协议
        if(onepk_data->iphead->protocol == PROTO_ICMP)
        {
            pk_tree_anainfo_icmp(onepk_data,root);
        }
        //UDP协议
        else if(onepk_data->iphead->protocol == PROTO_UDP)  //UDP协议
        {
            pk_tree_anainfo_udp(onepk_data,root);
        }
        //TCP协议包含http ftp smtp pop3
        else if(onepk_data->iphead->protocol == PROTO_TCP)
        {
            pk_tree_anainfo_tcp(onepk_data,root);
        }
    }
}

void MainWindow::pk_tree_anainfo_mac(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("数据链路层数据信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);


    tree_str = QString("源MAC地址: %1-%2-%3-%4-%5-%6").arg(onepk_data->machead->src[0], 2, 16, QChar('0'))
        .arg(onepk_data->machead->src[1], 2, 16, QChar('0'))
        .arg(onepk_data->machead->src[2], 2, 16, QChar('0'))
        .arg(onepk_data->machead->src[3], 2, 16, QChar('0'))
        .arg(onepk_data->machead->src[4], 2, 16, QChar('0'))
        .arg(onepk_data->machead->src[5], 2, 16, QChar('0'));
    QTreeWidgetItem *srcMac = new QTreeWidgetItem(depth);
    srcMac->setText(0, tree_str);


    tree_str = QString("目的MAC地址: %1-%2-%3-%4-%5-%6").arg(onepk_data->machead->des[0], 2, 16, QChar('0'))
        .arg(onepk_data->machead->des[1], 2, 16, QChar('0'))
        .arg(onepk_data->machead->des[2], 2, 16, QChar('0'))
        .arg(onepk_data->machead->des[3], 2, 16, QChar('0'))
        .arg(onepk_data->machead->des[4], 2, 16, QChar('0'))
        .arg(onepk_data->machead->des[5], 2, 16, QChar('0'));
    QTreeWidgetItem *desMac = new QTreeWidgetItem(depth);
    desMac->setText(0, tree_str);


    tree_str = QString("类型:0x%1").arg(onepk_data->machead->type, 4, 16, QChar('0'));
    QTreeWidgetItem *macType = new QTreeWidgetItem(depth);
    macType->setText(0, tree_str);
}

void MainWindow::pk_tree_anainfo_arp(poketdata *onepk_data, QTreeWidgetItem *root)
{
        QString tree_str = QString("ARP协议包信息");
        QTreeWidgetItem *depth = new QTreeWidgetItem(root);
        depth->setText(0, tree_str);

        tree_str = QString("硬件类型:0x%1").arg(onepk_data->arphead->hwtype, 4, 16, QChar('0'));
        QTreeWidgetItem *arp_htype = new QTreeWidgetItem(depth);
        arp_htype->setText(0, tree_str);

        tree_str = QString("协议类型: 0x%1").arg(onepk_data->arphead->protype,4, 16, QChar('0'));
        QTreeWidgetItem *arp_prtoype = new QTreeWidgetItem(depth);
        arp_prtoype->setText(0, tree_str);

        tree_str = QString("硬件地址长度: %1").arg(onepk_data->arphead->hwsize);
        QTreeWidgetItem *arp_hsize = new QTreeWidgetItem(depth);
        arp_hsize->setText(0, tree_str);

        tree_str = QString("协议地址长度: %1").arg(onepk_data->arphead->prosize);
        QTreeWidgetItem *arp_prosize = new QTreeWidgetItem(depth);
        arp_prosize->setText(0, tree_str);

        tree_str = QString("操作码: %1").arg(onepk_data->arphead->opcode);
        QTreeWidgetItem *arp_code = new QTreeWidgetItem(depth);
        arp_code->setText(0, tree_str);

        tree_str = QString("源MAC地址: %1-%2-%3-%4-%5-%6").arg(onepk_data->arphead->srcMAC[0], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->srcMAC[1], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->srcMAC[2], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->srcMAC[3], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->srcMAC[4], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->srcMAC[5], 2, 16, QChar('0'));
        QTreeWidgetItem *arp_srcmac = new QTreeWidgetItem(depth);
        arp_srcmac->setText(0, tree_str);

        tree_str = QString("源IP地址: %1.%2.%3.%4").arg(onepk_data->arphead->srcIP[0])
            .arg(onepk_data->arphead->srcIP[1])
            .arg(onepk_data->arphead->srcIP[2])
            .arg(onepk_data->arphead->srcIP[3]);
        QTreeWidgetItem *arp_srcip = new QTreeWidgetItem(depth);
        arp_srcip->setText(0, tree_str);

        tree_str = QString("目的MAC地址: %1-%2-%3-%4-%5-%6").arg(onepk_data->arphead->desMAC[0], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->desMAC[1], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->desMAC[2], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->desMAC[3], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->desMAC[4], 2, 16, QChar('0'))
            .arg(onepk_data->arphead->desMAC[5], 2, 16, QChar('0'));
        QTreeWidgetItem *arp_desmac = new QTreeWidgetItem(depth);
        arp_desmac->setText(0, tree_str);

        tree_str = QString("目的IP地址: %1.%2.%3.%4").arg(onepk_data->arphead->desIP[0])
            .arg(onepk_data->arphead->desIP[1])
            .arg(onepk_data->arphead->desIP[2])
            .arg(onepk_data->arphead->desIP[3]);
        QTreeWidgetItem *arp_desip = new QTreeWidgetItem(depth);
        arp_desip->setText(0, tree_str);
}

void MainWindow::pk_tree_anainfo_ip(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("IP协议包信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    tree_str = QString("版本: %1").arg(IP_V(onepk_data->iphead));
    QTreeWidgetItem *ip_v = new QTreeWidgetItem(depth);
    ip_v->setText(0, tree_str);

    tree_str = QString("IP首部长度: %1").arg(IP_HL(onepk_data->iphead));
    QTreeWidgetItem *ip_hlen = new QTreeWidgetItem(depth);
    ip_hlen->setText(0, tree_str);

    tree_str = QString("服务类型: %1").arg(onepk_data->iphead->tos);
    QTreeWidgetItem *ip_tos = new QTreeWidgetItem(depth);
    ip_tos->setText(0, tree_str);

    tree_str = QString("总长度: %1").arg(onepk_data->iphead->ip_pklen);
    QTreeWidgetItem *ip_pklen = new QTreeWidgetItem(depth);
    ip_pklen->setText(0, tree_str);

    tree_str = QString("标识: 0x%1").arg(onepk_data->iphead->ident,4,16,QChar('0'));
    QTreeWidgetItem *ipIdentify = new QTreeWidgetItem(depth);
    ipIdentify->setText(0, tree_str);

    tree_str = QString("保留片段标志: %1").arg((onepk_data->iphead->flags & IP_RF) >> 15);
    QTreeWidgetItem * ip_rf= new QTreeWidgetItem(depth);
    ip_rf->setText(0, tree_str);

    tree_str = QString("不分割标志: %1").arg((onepk_data->iphead->flags & IP_DF) >> 14);
    QTreeWidgetItem *ip_df = new QTreeWidgetItem(depth);
    ip_df->setText(0, tree_str);

    tree_str = QString("更多分段标志: %1").arg((onepk_data->iphead->flags & IP_MF) >> 13);
    QTreeWidgetItem *ip_mf = new QTreeWidgetItem(depth);
    ip_mf->setText(0, tree_str);

    tree_str = QString("段偏移: %1").arg(onepk_data->iphead->flags & IP_OFFMASK);
    QTreeWidgetItem *ip_offset = new QTreeWidgetItem(depth);
    ip_offset->setText(0, tree_str);

    tree_str = QString("生存期: %1").arg(onepk_data->iphead->TTL);
    QTreeWidgetItem *ip_ttl = new QTreeWidgetItem(depth);
    ip_ttl->setText(0, tree_str);

    tree_str = QString("协议: %1").arg(onepk_data->iphead->protocol);
    QTreeWidgetItem *ip_pro = new QTreeWidgetItem(depth);
    ip_pro->setText(0, tree_str);

    tree_str = QString("首部校验和: 0x%1").arg(onepk_data->iphead->hchecksum,4,16,QChar('0'));
    QTreeWidgetItem *ip_hchecks = new QTreeWidgetItem(depth);
    ip_hchecks->setText(0, tree_str);

    tree_str = QString("源IP地址: %1.%2.%3.%4").arg(onepk_data->iphead->src[0])
                                                        .arg(onepk_data->iphead->src[1])
                                                        .arg(onepk_data->iphead->src[2])
                                                        .arg(onepk_data->iphead->src[3]);
    QTreeWidgetItem *ip_src = new QTreeWidgetItem(depth);
    ip_src->setText(0, tree_str);

    tree_str = QString("目的IP地址: %1.%2.%3.%4").arg(onepk_data->iphead->des[0])
                                                              .arg(onepk_data->iphead->des[1])
                                                              .arg(onepk_data->iphead->des[2])
                                                              .arg(onepk_data->iphead->des[3]);
    QTreeWidgetItem *ip_des = new QTreeWidgetItem(depth);
    ip_des->setText(0, tree_str);
}

void MainWindow::pk_tree_anainfo_icmp(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("ICMP协议包信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    tree_str = QString("类型: %1").arg(onepk_data->icmphead->type);
    QTreeWidgetItem *icmp_type = new QTreeWidgetItem(depth);
    icmp_type->setText(0, tree_str);

    tree_str = QString("代码: %1").arg(onepk_data->icmphead->code);
    QTreeWidgetItem *icmp_code = new QTreeWidgetItem(depth);
    icmp_code->setText(0, tree_str);

    tree_str = QString("校验和: 0x%1").arg(onepk_data->icmphead->chk_sum,4,16,QChar('0'));
    QTreeWidgetItem *icmp_check = new QTreeWidgetItem(depth);
    icmp_check->setText(0, tree_str);

    tree_str = QString("标识: 0x%1").arg(onepk_data->icmphead->ident,4,16,QChar('0'));
    QTreeWidgetItem *icmp_iden = new QTreeWidgetItem(depth);
    icmp_iden->setText(0, tree_str);

    tree_str = QString("序列号: 0x%1").arg(onepk_data->icmphead->seq,4,16,QChar('0'));
    QTreeWidgetItem *icmp_seq = new QTreeWidgetItem(depth);
    icmp_seq->setText(0, tree_str);
}

void MainWindow::pk_tree_anainfo_udp(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("UDP协议包信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    tree_str = QString("源端口: %1").arg(onepk_data->udphead->srcport);
    QTreeWidgetItem *udp_srcp = new QTreeWidgetItem(depth);
    udp_srcp->setText(0, tree_str);

    tree_str = QString("目的端口: %1").arg(onepk_data->udphead->desport);
    QTreeWidgetItem *udp_desp = new QTreeWidgetItem(depth);
    udp_desp->setText(0, tree_str);

    tree_str = QString("总长度: %1").arg(onepk_data->udphead->len);
    QTreeWidgetItem *udp_len = new QTreeWidgetItem(depth);
    udp_len->setText(0, tree_str);

    tree_str = QString("校验和: 0x%1").arg(onepk_data->udphead->crc,4,16,QChar('0'));
    QTreeWidgetItem *udp_crc = new QTreeWidgetItem(depth);
    udp_crc->setText(0, tree_str);
}

void MainWindow::pk_tree_anainfo_tcp(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("TCP协议头");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    tree_str = QString("源端口: %1").arg(onepk_data->tcphead->srcport);
    QTreeWidgetItem *tcp_srcp = new QTreeWidgetItem(depth);
    tcp_srcp->setText(0, tree_str);

    tree_str = QString("目的端口: %1").arg(onepk_data->tcphead->desport);
    QTreeWidgetItem *tcp_desp = new QTreeWidgetItem(depth);
    tcp_desp->setText(0, tree_str);

    tree_str = QString("序列号: 0x%1").arg(onepk_data->tcphead->seq,8,16,QChar('0'));
    QTreeWidgetItem *tcp_seq = new QTreeWidgetItem(depth);
    tcp_seq->setText(0, tree_str);

    tree_str = QString("确认号: 0x%1").arg(onepk_data->tcphead->ack,8,16,QChar('0'));
    QTreeWidgetItem *tcp_ack = new QTreeWidgetItem(depth);
    tcp_ack->setText(0, tree_str);

    tree_str = QString("首部长度: %1 bytes (%2)").arg(TH_OFF(onepk_data->tcphead) * 4).arg(TH_OFF(onepk_data->tcphead));
    QTreeWidgetItem *tcp_hlen = new QTreeWidgetItem(depth);
    tcp_hlen->setText(0, tree_str);

    tree_str = QString("FLAG: 0x%1").arg(onepk_data->tcphead->th_flags,2,16,QChar('0'));
    QTreeWidgetItem *TCP_FLAGS = new QTreeWidgetItem(depth);
    TCP_FLAGS->setText(0, tree_str);

    tree_str = QString("CWR: %1").arg((onepk_data->tcphead->th_flags & TH_CWR) >> 7);
    QTreeWidgetItem *flag_cwr = new QTreeWidgetItem(TCP_FLAGS);
    flag_cwr->setText(0, tree_str);

    tree_str = QString("ECE: %1").arg((onepk_data->tcphead->th_flags & TH_ECE) >> 6);
    QTreeWidgetItem *flag_ece = new QTreeWidgetItem(TCP_FLAGS);
    flag_ece->setText(0, tree_str);

    tree_str = QString("URG: %1").arg((onepk_data->tcphead->th_flags & TH_URG) >> 5);
    QTreeWidgetItem *flag_urg = new QTreeWidgetItem(TCP_FLAGS);
    flag_urg->setText(0, tree_str);

    tree_str = QString("ACK: %1").arg((onepk_data->tcphead->th_flags & TH_ACK) >> 4);
    QTreeWidgetItem *flag_ack = new QTreeWidgetItem(TCP_FLAGS);
    flag_ack->setText(0, tree_str);

    tree_str = QString("PUSH: %1").arg((onepk_data->tcphead->th_flags & TH_PUSH) >> 3);
    QTreeWidgetItem *flag_push = new QTreeWidgetItem(TCP_FLAGS);
    flag_push->setText(0, tree_str);

    tree_str = QString("RST: %1").arg((onepk_data->tcphead->th_flags & TH_RST) >> 2);
    QTreeWidgetItem *flag_rst = new QTreeWidgetItem(TCP_FLAGS);
    flag_rst->setText(0, tree_str);

    tree_str = QString("SYN: %1").arg((onepk_data->tcphead->th_flags & TH_SYN) >> 1);
    QTreeWidgetItem *flag_syn = new QTreeWidgetItem(TCP_FLAGS);
    flag_syn->setText(0, tree_str);

    tree_str = QString("FIN: %1").arg((onepk_data->tcphead->th_flags & TH_FIN));
    QTreeWidgetItem *flag_fin = new QTreeWidgetItem(TCP_FLAGS);
    flag_fin->setText(0, tree_str);

    tree_str = QString("窗口大小: %1").arg(onepk_data->tcphead->win_size);
    QTreeWidgetItem *tcp_winsize = new QTreeWidgetItem(depth);
    tcp_winsize->setText(0, tree_str);

    tree_str = QString("校验和: 0x%1").arg(onepk_data->tcphead->checksum,4,16,QChar('0'));
    QTreeWidgetItem *tcp_check = new QTreeWidgetItem(depth);
    tcp_check->setText(0, tree_str);

    tree_str = QString("紧急指针: %1").arg(onepk_data->tcphead->urg);
    QTreeWidgetItem *tcp_urg = new QTreeWidgetItem(depth);
    tcp_urg->setText(0, tree_str);


    //协议
    if(onepk_data->isHttp == true)
    {
        pk_tree_anainfo_tcp_http(onepk_data,root);
    }
    else if(onepk_data->isHttps == true)
    {
        pk_tree_anainfo_tcp_https(onepk_data,root);
    }
    else if(onepk_data->isFtp == true)
    {
        pk_tree_anainfo_tcp_ftp(onepk_data,root);
    }

}

void MainWindow::pk_tree_anainfo_tcp_http(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("HTTP协议信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    QString http_content = "";
    u_char *http_head = onepk_data->appdata;
    u_char *http_point = NULL;
    const char *token[] = {"GET","POST","HTTP/1.1","HTTP/1.0"};

    for(int i = 0 ; i < 4 ; i ++){
        http_point = (u_char *)strstr((char *)http_head,token[i]);
        if(http_point){
            break;
        }
    }
    int size = onepk_data->appsize - (http_point - http_head);

    for(int i = 0 ; i < size; i++){
        if(http_point[i] == 0x0d){
            //如果到达http正文结尾
            if(http_point[i+1] == 0x0a && http_point[i+2] == 0x0d && http_point[i+3] == 0x0a){
                depth->addChild(new QTreeWidgetItem(depth,QStringList(http_content)));
                break;
            }
            else if(http_point[i+1] == 0x0a){
                http_content = "";
                i ++;
                continue;
            }
        }
        http_content += static_cast<QChar>(http_point[i]);
    }
    depth->addChild(new QTreeWidgetItem(depth,QStringList("(END)")));
}

void MainWindow::pk_tree_anainfo_tcp_https(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("HTTPS协议信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    depth->addChild(new QTreeWidgetItem(depth,QStringList("HTTPS内容为加密内容，无法展示")));
    depth->addChild(new QTreeWidgetItem(depth,QStringList("(END)")));
}

void MainWindow::pk_tree_anainfo_tcp_ftp(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("FTP协议信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    QString ftp_content = "";
    u_char *ftp_head = onepk_data->appdata;
    int size = onepk_data->appsize ;

    for(int i = 0 ; i < size; i++){
        if(ftp_head[i] == 0x0d){
            //遇到回车符号
            if(ftp_head[i+1] == 0x0a && ftp_head[i+2] == 0x0d && ftp_head[i+3] == 0x0a){
                ftp_content += "\\r\\n";
                depth->addChild(new QTreeWidgetItem(depth,QStringList(ftp_content)));
                depth->addChild(new QTreeWidgetItem(depth,QStringList("\\r\\n")));
                break;
            }
            else if(ftp_head[i+1] == 0x0a){
                depth->addChild(new QTreeWidgetItem(depth,QStringList(ftp_content + "\\r\\n")));
                ftp_content = "";
                i ++;
                continue;
            }
        }
        ftp_content += static_cast<QChar>(ftp_content[i]);
    }
    depth->addChild(new QTreeWidgetItem(depth,QStringList("(END)")));


}

void MainWindow::pk_tree_anainfo_tcp_smtp(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("smtp协议信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    QString smtp_content = "";
    u_char *smtp_head = onepk_data->appdata;
    int size = onepk_data->appsize ;

    for(int i = 0 ; i < size; i++){
        if(smtp_head[i] == 0x0d){
            //遇到回车符号
            if(smtp_head[i+1] == 0x0a && smtp_head[i+2] == 0x0d && smtp_head[i+3] == 0x0a){
                depth->addChild(new QTreeWidgetItem(depth,QStringList(smtp_content)));
                break;
            }
            else if(smtp_head[i+1] == 0x0a){
                smtp_content = "";
                i ++;
                continue;
            }
        }
        smtp_content += static_cast<QChar>(smtp_content[i]);
    }
    depth->addChild(new QTreeWidgetItem(depth,QStringList("(END)")));
}

void MainWindow::pk_tree_anainfo_tcp_pop3(poketdata *onepk_data, QTreeWidgetItem *root)
{
    QString tree_str = QString("pop3协议信息");
    QTreeWidgetItem *depth = new QTreeWidgetItem(root);
    depth->setText(0, tree_str);

    QString pop3_content = "";
    u_char *pop3_head = onepk_data->appdata;
    int size = onepk_data->appsize ;

    for(int i = 0 ; i < size; i++){
        if(pop3_head[i] == 0x0d){
            //遇到回车符号
            if(pop3_head[i+1] == 0x0a && pop3_head[i+2] == 0x0d && pop3_head[i+3] == 0x0a){
                depth->addChild(new QTreeWidgetItem(depth,QStringList(pop3_content)));
                break;
            }
            else if(pop3_head[i+1] == 0x0a){
                pop3_content = "";
                i ++;
                continue;
            }
        }
        pop3_content += static_cast<QChar>(pop3_content[i]);
    }
    depth->addChild(new QTreeWidgetItem(depth,QStringList("(END)")));
}

void MainWindow::pk_tree_table(int row)
{
    //清空组件

    ui->protocol_tree->clear();
    ui->detail_table->clear();
    ui->protocol_tree->setHeaderLabels(QStringList("数据包分析"));

    struct poketdata *onepk_data = (struct poketdata *) pk_vec[row];
    u_char *print_data = (u_char *)data_vec[row];
    int print_len = onepk_data->len;
    //在table2中显示包16进制信息
    pk_content16(print_data,print_len);
    //在tree中显示数据包分析
    pk_tree_anainfo(onepk_data,row);

}



QString MainWindow::getfilter(QString pro, QString srcip, QString desip)
{
    int comb = 0;
    QString fil;
    QString profil;
    qDebug()<<"getfilter.....pro:"<<pro;

    if(pro !="all")
        comb+=1;
    if(!srcip.isEmpty())
        comb+=2;
    if(!desip.isEmpty())
        comb+=4;

    switch(comb){
    case 0:
        fil="";
        break;
    case 1:
        profil = profilter(pro);
        qDebug()<<"getfilter1.....profil:"<<profil;
        fil = profil;
        break;
    case 2:
        fil="src host "+srcip;
        break;
    case 3:
        profil = profilter(pro);
        qDebug()<<"getfilter3.....profil:"<<profil;
        fil=profil+" and "+"src host "+srcip;
        break;
    case 4:
        fil="dst host "+desip;
        break;
    case 5:
        profil = profilter(pro);
        qDebug()<<"getfilter5.....profil:"<<profil;
        fil=profil+" and "+"dst host "+desip;
        break;
    case 6:
        fil="src host "+srcip+" and dst host "+desip;
        break;
    case 7:
        profil = profilter(pro);
        qDebug()<<"getfilter7.....profil:"<<profil;
        fil=profil+" and "+"src host "+srcip+" and "+"dst host "+desip;
        break;
    default:
        fil="error";
        break;
    }

    qDebug()<<"getfilter.....fil:"<<fil;
    return fil;
}

QString MainWindow::profilter(QString pro)
{
    QString str_pro = "";
    if(pro == "tcp")
    {
        str_pro ="tcp";
    }
    else if(pro == "udp")
    {
        str_pro = "udp";
    }
    else if(pro == "ipv4")
    {
        str_pro = "ip";
    }
    else if(pro == "icmp")
    {
        str_pro = "icmp";
    }
    else if(pro == "arp")
    {
        str_pro = "arp";
    }
    else if(pro == "http")
    {
        str_pro = "tcp and port 80";
    }
    else if(pro == "https")
    {
        str_pro = "tcp and port 443";
    }
    else if(pro == "ftp")
    {
        str_pro = "tcp port 21 or port 20";
    }
    else if(pro == "smtp")
    {
        str_pro = "tcp and port  25";
    }
    else if(pro == "pop3")
    {
        str_pro = "tcp and port  110";
    }
    return str_pro;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->endpt->setEnabled(false);
    //0.基本设置
    this->setfilt();
    this->set_table_tree();

    //1.设置网卡
    if(this->setNetdevs()){
        qDebug()<<"获取网卡资源成功";

    }
    else
    {
        QWidget w;
        QMessageBox::warning(&w, "错误","获取网卡资源失败，请重试");
        qDebug()<<"获取网卡资源失败，请重试";
        exit(-1);
    }

    pk_cont = (poketcont *)malloc(sizeof(poketcont));
    cap=NULL;

}

void MainWindow::clear_tab_tree()
{
    ui->ipv4line->setText(QString('0'));
    ui->arpline->setText(QString('0'));
    ui->httpline->setText(QString('0'));
    ui->tcpline->setText(QString('0'));
    ui->udpline->setText(QString('0'));
    ui->icmpline->setText(QString('0'));
    ui->smtpline->setText(QString('0'));
    ui->pop3line->setText(QString('0'));
    ui->ftpline->setText(QString('0'));
    ui->otherline->setText(QString('0'));
    ui->toalline->setText(QString('0'));

    ui->cap_table->clear();
    ui->cap_table->setRowCount(0);
    ui->cap_table->setColumnCount(9);
    QStringList header;
    header<< tr("序号") << tr("时间")<< tr("源MAC地址")<< tr("源IP地址") << tr("目的MAC地址")<< tr("目的IP地址")<< tr("长度") << tr("协议类型")<<tr("包信息");
    ui->cap_table->setHorizontalHeaderLabels(header);
    ui->protocol_tree->clear();
    ui->detail_table->clear();
    ui->detail_table->setRowCount(0);

}


MainWindow::~MainWindow()
{
    delete ui;
}





void MainWindow::on_startpt_clicked()
{
    //组件设置
    ui->startpt->setEnabled(false);
    ui->endpt->setEnabled(true);
    ui->netbox->setEnabled(false);
    ui->protocolbox->setEnabled(false);
    ui->srcline->setEnabled(false);
    ui->desline->setEnabled(false);
    //释放容器
    pk_vec.clear();
    data_vec.clear();
    memset(pk_cont, 0, sizeof(struct poketcont));
    qDebug()<<"释放成功";
    //清空组件
    clear_tab_tree();

    if(devs == NULL){
        if(initcap() < 0){
            QMessageBox::warning(this, tr("error"), tr("无法在您的机器上获取网络适配器接口"), QMessageBox::Ok);
            return;
        }
    }
    if(cap != NULL){
        free(cap);
        cap = NULL;
    }

    if(startcap() < 0)
        return;//开始捕获数据包
}

void MainWindow::updateCapCalculate()
{
    ui->tcpline->setText(QString::number(pk_cont->n_tcp));
    ui->udpline->setText(QString::number(pk_cont->n_udp));
    ui->arpline->setText(QString::number(pk_cont->n_arp));
    ui->ipv4line->setText(QString::number(pk_cont->n_ip));
    ui->icmpline->setText(QString::number(pk_cont->n_icmp));
    ui->otherline->setText(QString::number(pk_cont->n_other));
    ui->toalline->setText(QString::number(pk_cont->n_sum));
    ui->httpline->setText(QString::number(pk_cont->n_http));
    ui->httpsline->setText(QString::number(pk_cont->n_https));
    ui->ftpline->setText(QString::number(pk_cont->n_ftp));
    ui->smtpline->setText(QString::number(pk_cont->n_smtp));
    ui->pop3line->setText(QString::number(pk_cont->n_pop3));
}

void MainWindow::updateTableWidget(QString timestr, QString srcMac, QString destMac, QString len, QString protoType, QString srcIP, QString dstIP)
{
    int rowcount;
    rowcount = ui->cap_table->rowCount();
    ui->cap_table->insertRow(rowcount);
    QString No = QString::number(rowcount,10);
    ui->cap_table->setItem(rowcount,0,new QTableWidgetItem(No));
    ui->cap_table->setItem(rowcount,1,new QTableWidgetItem(timestr));
    ui->cap_table->setItem(rowcount,2,new QTableWidgetItem(srcMac));
    ui->cap_table->setItem(rowcount,3,new QTableWidgetItem(srcIP));
    ui->cap_table->setItem(rowcount,4,new QTableWidgetItem(destMac));
    ui->cap_table->setItem(rowcount,5,new QTableWidgetItem(dstIP));
    ui->cap_table->setItem(rowcount,6,new QTableWidgetItem(len));
    ui->cap_table->setItem(rowcount,7,new QTableWidgetItem(protoType));
    ui->cap_table->setItem(rowcount,8,new QTableWidgetItem("null"));

    if(rowcount > 1)
    {
        ui->cap_table->scrollToItem(ui->cap_table->item(rowcount,0));
    }
    QColor color;
    if(protoType == "TCP" || protoType == "HTTP"|| protoType == "HTTPS")
    {
        color = QColor(224,255,199);
    }
    else if(protoType == "FTP")
    {
        color = QColor(228,245,199);
    }
    else if(protoType == "SMTP")
    {
        color = QColor(228,235,199);
    }

    else if(protoType == "POP3")
    {
        color = QColor(228,205,199);
    }
    else if(protoType == "UDP")
    {
        color = QColor(218,238,255);
    }
    else if(protoType == "ARP")
    {
        color = QColor(250,240,215);
    }
    else if(protoType == "ICMP")
    {
        color = QColor(252,224,255);
    }
    for(int i = 0; i < 9 ; i ++)
    {
        ui->cap_table->item(rowcount,i)->setBackground(color);
    }
}


void MainWindow::on_endpt_clicked()
{
    ui->startpt->setEnabled(true);
    ui->endpt->setEnabled(false);
    ui->netbox->setEnabled(true);
    ui->srcline->setEnabled(true);
    ui->desline->setEnabled(true);
    ui->protocolbox->setEnabled(true);
    cap->stop();
    pcap_close(pk_handle);
}


void MainWindow::on_cap_table_cellDoubleClicked(int row)
{
    pk_tree_table(row);
}


