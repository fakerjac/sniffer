#include "mainwindow.h"

#include <QApplication>
#include <QDebug>
#include "pcap.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("嗅探器_vision 2.0");
    w.show();


    return a.exec();
}
