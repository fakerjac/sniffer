#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <pcap.h>
#include <iostream>
#include <pro_def.h>
#include <cap_poket.h>
#include <QTreeWidgetItem>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    pcap_if_t *devs;//用于查找设备
    pcap_if_t *devi;//用于循环遍历
    pcap_if_t *nowdev;//当前使用设备
    pcap_t *pk_handle;//处理捕获数据包的指针
    poketcont *pk_cont;//不同包的数量
    cap_poket *cap;//抓包线程对象
    poketdataves pk_vec;//包数据数组
    datavec data_vec;//数据数组
    int devCount;//设备数量
    char errbuf[PCAP_ERRBUF_SIZE];//用于记录错误信息


    MainWindow(QWidget *parent = nullptr);
    void clear_tab_tree();
    QString getfilter(QString pro,QString srcip,QString decip);//处理过滤器
    QString profilter(QString pro);//处理所选协议
    void freedevs(pcap_if_t *devs);//释放设备资源
    bool setNetdevs();//读取网卡设备
    void setfilt();//设置初始过滤条件
    void set_table_tree();//设置表格等初始状态
    int startcap();//开始捕获数据包
    int initcap();//初始化抓取线程

    void pk_tree_table(int row);//用tree,table显示包具体信息
    void pk_content16(u_char *print_data,int len);//显示数据包内容
    void pk_tree_anainfo(struct poketdata *onepk_data,int row);//在树结构中显示分析包的总结构
    //以下为各个类型的包的显示
    void pk_tree_anainfo_mac(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_arp(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_ip(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_icmp(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_udp(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_tcp(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_tcp_http(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_tcp_https(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_tcp_ftp(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_tcp_smtp(poketdata *onepk_data,QTreeWidgetItem *root);
    void pk_tree_anainfo_tcp_pop3(poketdata *onepk_data,QTreeWidgetItem *root);
    ~MainWindow();

private slots:
    void on_startpt_clicked();
    void updateCapCalculate();
    void updateTableWidget(QString timestr, QString srcMac, QString destMac, QString len, QString protoType, QString srcIP, QString dstIP);

    void on_endpt_clicked();

    void on_cap_table_cellDoubleClicked(int row);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
