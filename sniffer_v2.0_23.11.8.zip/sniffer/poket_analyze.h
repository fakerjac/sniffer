#ifndef POKET_ANALYZE_H
#define POKET_ANALYZE_H
#define WPCAP
#define HAVE_REMOTE
#include <pcap.h>
#include <pro_def.h>
#include <remote-ext.h>



class poket_analyze
{
public:
    poket_analyze();
    int ana_pk(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont);
    int ana_arp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont);
    int ana_ip(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont);
    int ana_icmp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont);
    int ana_tcp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont);
    int ana_udp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont);
    bool ishttp(struct TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont);
    bool ishttps(struct TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont);
    bool isftp(struct TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont);
    bool issmtp(struct TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont);
    bool ispop3(struct TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont);
private:
    const u_char *pk_IniAd;  //捕获的数据包的起始地址

};

#endif // POKET_ANALYZE_H
