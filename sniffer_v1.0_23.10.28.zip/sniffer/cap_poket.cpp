#include "cap_poket.h"
#include <ctime>
#include <poket_analyze.h>
#include <QTextStream>
#include <QDebug>


cap_poket::cap_poket(pcap_t *pk_handle, poketcont *pk_cont, poketdataves &pk_ves, datavec &data_ves):
    pk_ves(pk_ves),data_ves(data_ves)
{
    isstop=false;
    this->pk_handle = pk_handle;
    this->pk_cont = pk_cont;
}

void cap_poket::stop()
{
    QMutexLocker locker(&m_lock);
    isstop = true;
}

void cap_poket::run()
{
    int cap_ret;//抓包函数返回值
    struct tm *ltime;
    time_t local_tv_sec;
    struct pcap_pkthdr *head;
    const u_char *pk_data = NULL;
    qDebug()<<"cap_run start....";
    while(isstop ==false &&(cap_ret = pcap_next_ex(pk_handle,&head,&pk_data)) >=0)
    {
        //qDebug()<<"cap_poket 开始抓包。。";
        if(cap_ret == 0)
        {
            qDebug()<<"cap_poket 抓包超时....";
            continue;//超时
        }

        //存储捕获包信息
        struct poketdata *data =(struct poketdata*)malloc(sizeof(struct poketdata));
        data->isHttp = false;
        memset(data,0,sizeof(struct poketdata));
        data->len = head->len;

        //分析数据包
        poket_analyze* pkana = new poket_analyze;
        if(pkana->ana_pk(pk_data,data,pk_cont)<0)
        {
            qDebug()<<"cap_poket  包分析错误，或没有预计协议包";
            continue;
        }
        qDebug()<<"cap_run 分析包结束。。。。";
        //数据放入表中
        u_char *ppk_data =(u_char *)malloc(head->len * sizeof(u_char));
        memcpy(ppk_data, pk_data, head->len);

        pk_ves.push_back(data);
        data_ves.push_back(ppk_data);
        qDebug()<<"cap_run 数据放入表结束。。";


        //更新ui包统计数据
        emit updatePktCont();


        //更新ui中cap_table信息
        //处理时间
        local_tv_sec = head->ts.tv_sec;
        ltime = localtime(&local_tv_sec);
        data->time[0] = ltime->tm_year + 1900;
        data->time[1] = ltime->tm_mon + 1;
        data->time[2] = ltime->tm_mday;
        data->time[3] = ltime->tm_hour;
        data->time[4] = ltime->tm_min;
        data->time[5] = ltime->tm_sec;

        //获取时间戳
        QString timestr;
        QTextStream(&timestr) << data->time[0] << "/"
                              << data->time[1] << "/"
                              << data->time[2]<< " "
                              << data->time[3] << ":"
                              << data->time[4]<< ":"
                              << data->time[5];

        //获取数据包长度
        QString pkt_len = QString::number(data->len);
        //获取源MAC地址
        QString srcMac;
        srcMac = QString("%1-%2-%3-%4-%5-%6").arg(data->machead->src[0],2,16,QChar('0'))
            .arg(data->machead->src[1],2,16,QChar('0'))
            .arg(data->machead->src[2],2,16,QChar('0'))
            .arg(data->machead->src[3],2,16,QChar('0'))
            .arg(data->machead->src[4],2,16,QChar('0'))
            .arg(data->machead->src[5],2,16,QChar('0'));
        //获取目的MAC地址
        QString desMac;
        desMac = QString("%1-%2-%3-%4-%5-%6").arg(data->machead->des[0],2,16,QChar('0'))
            .arg(data->machead->des[1],2,16,QChar('0'))
            .arg(data->machead->des[2],2,16,QChar('0'))
            .arg(data->machead->des[3],2,16,QChar('0'))
            .arg(data->machead->des[4],2,16,QChar('0'))
            .arg(data->machead->des[5],2,16,QChar('0'));
        //获得协议
        QString pro_Type = QString(data->pokettype);
        //获得源IP地址
        QString srcIP;
        if(data->machead->type == 0x0806)  //ARP
        {
            srcIP = QString("%1.%2.%3.%4").arg(data->arphead->srcIP[0])
                .arg(data->arphead->srcIP[1])
                .arg(data->arphead->srcIP[2])
                .arg(data->arphead->srcIP[3]);
        }
        else if(data->machead->type == 0x0800) //IP
        {
            srcIP = QString("%1.%2.%3.%4").arg(data->iphead->src[0])
                .arg(data->iphead->src[1])
                .arg(data->iphead->src[2])
                .arg(data->iphead->src[3]);
        }

        //获得目的IP地址
        QString desIP;
        if(data->machead->type == 0x0806)
        {
            desIP = QString("%1.%2.%3.%4").arg(data->arphead->desIP[0])
                .arg(data->arphead->desIP[1])
                .arg(data->arphead->desIP[2])
                .arg(data->arphead->desIP[3]);
        }
        else if(data->machead->type == 0x0800)
        {
            desIP = QString("%1.%2.%3.%4").arg(data->iphead->des[0])
                .arg(data->iphead->des[1])
                .arg(data->iphead->des[2])
                .arg(data->iphead->des[3]);
        }
        qDebug()<<"cap_poket run....srcIP:"<<srcIP;
        qDebug()<<"cap_poket run....desIP:"<<desIP;
        emit addOneCaptureLine(timestr, srcMac, desMac, pkt_len, pro_Type, srcIP, desIP);

        qDebug()<<"cap_run 更新ui表 end....";
    }
}


