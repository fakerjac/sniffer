#ifndef CAP_POKET_H
#define CAP_POKET_H

#include <QThread>
#include <pcap.h>
#include <pro_def.h>
#include <QMutex>

class cap_poket : public QThread
{
    Q_OBJECT
public:

    cap_poket(pcap_t *pk_handle,poketcont *pk_cont,poketdataves &pk_ves,datavec &date_ves);
    void stop();
    void run();
private:
    pcap_t *pk_handle;
    poketcont *pk_cont;
    poketdataves &pk_ves;
    datavec &data_ves;
    bool isstop;
    QMutex m_lock;

signals:
    void updatePktCont();
    void addOneCaptureLine(QString timestr, QString srcMac, QString destMac, QString len, QString protoType, QString srcIP, QString dstIP);
};

#endif // CAP_POKET_H
