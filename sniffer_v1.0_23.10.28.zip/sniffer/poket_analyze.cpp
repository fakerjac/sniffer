#include "poket_analyze.h"
#include <QDebug>
#include <WinSock2.h>

poket_analyze::poket_analyze()
{

}

int poket_analyze::ana_pk(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont)
{
    pk_IniAd = pkt;
    struct MACHead *mac = (struct MACHead *)pkt;
    pk_data->machead = (struct MACHead *)malloc(sizeof(struct MACHead));
    if(pk_data->machead == NULL){
        qDebug() << "ana_pk  machead 内存分配失败";
        return -1;
    }
    for(int i = 0; i < 6; ++i)
    {
        pk_data->machead->des[i] = mac->des[i];
        pk_data->machead->src[i] = mac->src[i];
    }
    //数据包的总数加1
    pk_cont->n_sum++;
    //由于网络字节顺序的原因，需要进行对齐
    pk_data->machead->type = ntohs(mac->type);

    int ret = 0;

    //对上层协议类型做进一步的判断，并做进一步的拆包分析
    switch(pk_data->machead->type)
    {
    case PRO_IP:
        ret = ana_ip((u_char *)pkt + 14, pk_data, pk_cont);
        break;
    case PRO_ARP:
        ret = ana_arp((u_char *)pkt + 14, pk_data, pk_cont);
        break;
    default:
        pk_cont->n_other++;
        ret = -1;
        break;
    }

    return ret;
}

int poket_analyze::ana_arp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont)
{
    struct ARPHead *arp = (struct ARPHead *)pkt;
    pk_data->arphead = (struct ARPHead *)malloc(sizeof(struct ARPHead));
    if(pk_data->arphead == NULL)
    {
        qDebug() << "failed to malloc arph space!" ;
        return -1;
    }
    //复制IP
    for(int i = 0; i < 6; i++)
    {
        if(i < 4)
        {
            pk_data->arphead->srcIP[i]= arp->srcIP[i];
            pk_data->arphead->desIP[i] = arp->desIP[i];
        }
        pk_data->arphead->srcMAC[i] = arp->srcMAC[i];
        pk_data->arphead->desMAC[i] = arp->desMAC[i];
    }

    pk_data->arphead->hwtype = ntohs(arp->hwtype);
    pk_data->arphead->protype = ntohs(arp->protype);
    pk_data->arphead->hwsize = arp->hwsize;
    pk_data->arphead->prosize = arp->prosize;
    pk_data->arphead->opcode = ntohs(arp->opcode);

    strcpy(pk_data->pokettype, "ARP");
    pk_cont->n_arp++;
    return 1;
}

int poket_analyze::ana_ip(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont)
{
    struct IPHead *ip = (struct IPHead*)pkt;
    pk_data->iphead = (struct IPHead*)malloc(sizeof(struct IPHead));
    if(pk_data->iphead == NULL)
    {
        qDebug() << "failed to malloc ip header space!";
        return -1;
    }
    pk_data->iphead->hchecksum = ntohs(ip->hchecksum);
    pk_cont->n_ip++;

    for(int i = 0;i<4;i++)
    {
        pk_data->iphead->src[i] = ip->src[i];
        pk_data->iphead->des[i] = ip->des[i];
    }
    char buf[100];
    sprintf(buf,"ana_ip ip-> src: %02x %02x %02x %02x",ip->src[0],ip->src[1],ip->src[2],ip->src[3]);
    qDebug()<<buf;
    sprintf(buf,"ana_ip ip-> des: %02x %02x %02x %02x",ip->des[0],ip->des[1],ip->des[2],ip->des[3]);
    qDebug()<<buf;

    pk_data->iphead->tos = ip->tos;
    pk_data->iphead->ip_v_hlen = ip->ip_v_hlen;
    pk_data->iphead->ip_pklen = ntohs(ip->ip_pklen);
    pk_data->iphead->ident = ntohs(ip->ident);
    pk_data->iphead->flags = ntohs(ip->flags);
    pk_data->iphead->TTL = ip->TTL;
    pk_data->iphead->protocol = ip->protocol;

    u_int ipheader_len = IP_HL(pk_data->iphead) * 4;
    int ret = 0;
    switch(ip->protocol)
    {
    case PROTO_ICMP:
        ret = ana_icmp((u_char*)ip+ipheader_len,pk_data,pk_cont);
        break;
    case PROTO_TCP:
        ret = ana_tcp((u_char*)ip+ipheader_len,pk_data,pk_cont);
        break;
    case PROTO_UDP:
        ret = ana_udp((u_char*)ip+ipheader_len,pk_data,pk_cont);
        break;
    default :
        pk_cont->n_other++;
        ret = -1;
        break;
    }
    return ret;
}

int poket_analyze::ana_icmp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont)
{
    struct ICMPHead* icmp = (struct ICMPHead*)pkt;
    pk_data->icmphead = (struct ICMPHead*)malloc(sizeof(struct ICMPHead));

    if(NULL == pk_data->icmphead)
        return -1;

    pk_data->icmphead->chk_sum = icmp->chk_sum;
    pk_data->icmphead->code = icmp->code;
    pk_data->icmphead->seq =ntohs(icmp->seq);
    pk_data->icmphead->type = icmp->type;
    pk_data->icmphead->ident = ntohs(icmp->ident);
    pk_data->icmphead->chk_sum = ntohs(icmp->chk_sum);
    strcpy(pk_data->pokettype,"ICMP");
    pk_cont->n_icmp++;
    return 1;
}

int poket_analyze::ana_tcp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont)
{
    struct TCPHead *tcp = (struct TCPHead *)pkt;
    pk_data->tcphead = (struct TCPHead *)malloc(sizeof(struct TCPHead));
    if(pk_data->tcphead == NULL)
    {
        qDebug() << "failed to malloc tcp header space!";
        return -1;
    }

    pk_cont->n_tcp++;

    pk_data->tcphead->srcport = ntohs(tcp->srcport);
    pk_data->tcphead->desport = ntohs(tcp->desport);
    pk_data->tcphead->seq =ntohs(tcp->seq);
    pk_data->tcphead->ack = ntohs(tcp->ack);
    pk_data->tcphead->th_off = tcp->th_off;
    pk_data->tcphead->th_flags = tcp->th_flags;
    pk_data->tcphead->win_size= ntohs(tcp->win_size);
    pk_data->tcphead->checksum = ntohs(tcp->checksum);
    pk_data->tcphead->urg = ntohs(tcp->urg);
    strcpy(pk_data->pokettype, "TCP");

    //根据端口设置包
    if(pk_data->tcphead->srcport == 80 || pk_data->tcphead->desport == 80)
    {
        if(ishttp(tcp,pk_data,pk_cont)) return 1;
    }
    else if(pk_data->tcphead->srcport == 20 || pk_data->tcphead->desport == 20 ||
               pk_data->tcphead->srcport == 21 || pk_data->tcphead->desport == 21)
    {
        if(isftp(tcp,pk_data,pk_cont)) return 1;
    }
    else if(pk_data->tcphead->srcport == 25 || pk_data->tcphead->desport == 25)
    {
        if(issmtp(tcp,pk_data,pk_cont)) return 1;
    }
    else if(pk_data->tcphead->srcport == 161 || pk_data->tcphead->desport == 161
               ||pk_data->tcphead->srcport == 162 || pk_data->tcphead->desport == 162)
    {
        if(issnmp(tcp,pk_data,pk_cont)) return 1;
    }
    else if(pk_data->tcphead->srcport == 110 || pk_data->tcphead->desport == 110)
    {
        if(ispop3(tcp,pk_data,pk_cont)) return 1;
    }

    return 1;
}

int poket_analyze::ana_udp(const u_char *pkt, poketdata *pk_data, poketcont *pk_cont)
{
    struct UDPHead *udp = (struct UDPHead *)pkt;
    pk_data->udphead = (struct UDPHead *)malloc(sizeof(struct UDPHead));
    if(pk_data->udphead == NULL)
    {
        qDebug() << "ana_udp 空间申请失败!" ;
        return -1;
    }
    pk_data->udphead->srcport = ntohs(udp->srcport);
    pk_data->udphead->desport = ntohs(udp->desport);
    pk_data->udphead->len = ntohs(udp->len);
    pk_data->udphead->crc = ntohs(udp->crc);

    strcpy(pk_data->pokettype,"UDP");
    pk_cont->n_udp++;
    return 1;
}

bool poket_analyze::ishttp(struct TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont)
{
    u_char *httpdata = (u_char *)tcp + TH_OFF(tcp) * 4;
    const char *feature[] = {"GET","POST","HTTP/1.1","HTTP/1.0"};
    u_char *httpheader;

    //查找包中是否有http特征出现，有就是http包
    for(int i = 0 ; i < 4 ; i ++){
        httpheader = (u_char *)strstr((char *)httpdata,feature[i]);
        if(httpheader){

            pk_cont->n_http++;
            strcpy(pk_data->pokettype, "HTTP");
            pk_data->isHttp = true;
            qDebug() << "ishttp  找到一个http包";

            int size =pk_data->len - ((u_char *)httpdata - pk_IniAd);

            qDebug() << "ishttp size: " << size;

            pk_data->appsize = size;
            pk_data->appdata = (u_char *)malloc(size * sizeof(u_char));
            for(int j = 0; j < size; j++){
                pk_data->appdata[j] = httpdata[j];
            }

            return true;
        }
    }
    return false;
}

bool poket_analyze::isftp(TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont)
{
    u_char *ftpdata = (u_char *)tcp + TH_OFF(tcp) * 4;
    pk_cont->n_ftp++;
    strcpy(pk_data->pokettype, "FTP");
    pk_data->isFtp = true;
    qDebug() << "isftp  找到一个ftp包";

    int size =pk_data->len - ((u_char *)ftpdata - pk_IniAd);

    qDebug() << "isftp size: " << size;

    pk_data->appsize = size;
    pk_data->appdata = (u_char *)malloc(size * sizeof(u_char));
    for(int j = 0; j < size; j++){
        pk_data->appdata[j] = ftpdata[j];
    }
    return true;
}

bool poket_analyze::issmtp(TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont)
{
    u_char *smtpdata = (u_char *)tcp + TH_OFF(tcp) * 4;
    pk_cont->n_smtp++;
    strcpy(pk_data->pokettype, "SMTP");
    pk_data->isSmtp = true;

    int size =pk_data->len - ((u_char *)smtpdata - pk_IniAd);

    pk_data->appsize = size;
    pk_data->appdata = (u_char *)malloc(size * sizeof(u_char));
    for(int j = 0; j < size; j++){
        pk_data->appdata[j] = smtpdata[j];
    }
    return true;
}

bool poket_analyze::issnmp(TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont)
{
    u_char *snmpdata = (u_char *)tcp + TH_OFF(tcp) * 4;
    pk_cont->n_snmp++;
    strcpy(pk_data->pokettype, "SNMP");
    pk_data->isSnmp = true;

    int size =pk_data->len - ((u_char *)snmpdata - pk_IniAd);

    pk_data->appsize = size;
    pk_data->appdata = (u_char *)malloc(size * sizeof(u_char));
    for(int j = 0; j < size; j++){
        pk_data->appdata[j] = snmpdata[j];
    }
    return true;
}

bool poket_analyze::ispop3(TCPHead *tcp, poketdata *pk_data, poketcont *pk_cont)
{
    u_char *pop3data = (u_char *)tcp + TH_OFF(tcp) * 4;
    pk_cont->n_pop3++;
    strcpy(pk_data->pokettype, "POP3");
    pk_data->isPop3 = true;

    int size =pk_data->len - ((u_char *)pop3data - pk_IniAd);

    pk_data->appsize = size;
    pk_data->appdata = (u_char *)malloc(size * sizeof(u_char));
    for(int j = 0; j < size; j++){
        pk_data->appdata[j] = pop3data[j];
    }
    return true;
}
