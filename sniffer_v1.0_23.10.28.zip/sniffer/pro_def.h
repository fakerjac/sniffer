#ifndef PRO_DEF_H
#define PRO_DEF_H

#include <iostream>
#include <vector>
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

using namespace std;

typedef struct MACHead
{
    u_char des[6];
    u_char src[6];
    u_short type;
}MACHAead;

#define MACHead_size 14

#define PRO_IP 0x0800
#define PRO_ARP 0x0806

typedef struct ARPHead
{
    u_short hwtype;
    u_short protype;
    u_char hwsize;
    u_char prosize;
    u_short opcode;
    u_char srcMAC[6];
    u_char srcIP[4];
    u_char desMAC[6];
    u_char desIP[4];
}ARPHead;

typedef struct IPHead
{
#define IP_RF 0x8000        //reservedfragment flag
#define IP_DF 0x4000        //don't fragment flag
#define IP_MF 0x2000        //more fragment flag
#define IP_OFFMASK 0x1fff   //mask for fragment offset bits
    u_char ip_v_hlen;
    u_char tos;
    u_short ip_pklen;
    u_short ident;
    u_short flags;
    u_char TTL;
    u_char protocol;
    u_short hchecksum;
    u_char src[4];
    u_char des[4];

}IPHead;

#define IP_HL(ip)       ((ip)->ip_v_hlen & 0x0f)   //得到后4位，即报文的首部长度
#define IP_V(ip)        (((ip)->ip_v_hlen) >> 4)

#define PROTO_ICMP 1
#define PROTO_TCP 6
#define PROTO_UDP 17

typedef struct TCPHead
{
#define TH_OFF(th) (((th)->th_off & 0xf0) >> 4)   //得到前4位，即包首部长度

#define TH_FIN 0X01
#define TH_SYN 0x02
#define TH_RST 0x04
#define TH_PUSH 0x08
#define TH_ACK 0x10
#define TH_URG 0x20
#define TH_ECE 0x40
#define TH_CWR 0X80
#define TH_FLAGS (TH_FIN|TH_SYN|TH_RST|TH_ACK|TH_URG|TH_ECE|TH_CWR)
    u_short srcport;
    u_short desport;
    u_int seq;
    u_int ack;
    u_char th_off;
    u_char th_flags;
    u_short win_size;
    u_short checksum;
    u_short urg;
}TCPHead;

typedef struct UDPHead
{
    u_short srcport;  //源端口
    u_short desport;  //目的端口
    u_short len;    //UDP数据包长度
    u_short crc;    //校验和
}UDPHead;

typedef struct ICMPHead
{
    u_char type;        //类型字段，占8位
    u_char code;        //代码字段，占8位
    u_short chk_sum;    //校验和字段，占16位
    u_short ident; //标识符字段，占16位
    u_short seq;    //序列号字段，占16位
}ICMPHead;

typedef struct poketcont
{
    int n_ip;
    int n_arp;
    int n_tcp;
    int n_udp;
    int n_icmp;
    int n_http;
    int n_ftp;
    int n_smtp;
    int n_snmp;
    int n_pop3;
    int n_other;
    int n_sum;
}poketcont;

typedef struct poketdata
{
    char pokettype[8];        //包类型
    int time[6];            //时间戳
    int len;                //长度

    struct MACHead *machead;    //链路层包头
    struct ARPHead *arphead;    //arp包头
    struct IPHead *iphead;      //ip包头
    struct ICMPHead *icmphead;  //icmp包头
    struct UDPHead *udphead;    //udp包头
    struct TCPHead *tcphead;    //tcp包头
    u_char* appdata;     //应用层数据
    bool isHttp = false;
    bool isFtp = false;
    bool isSmtp = false;
    bool isSnmp = false;
    bool isPop3 = false;
    int appsize;
}poketdata;

typedef vector<poketdata *> poketdataves;

typedef vector<u_char *> datavec;

#endif // PRO_DEF_H
